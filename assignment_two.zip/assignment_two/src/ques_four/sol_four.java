package ques_four;

public class sol_four {
		// TODO Auto-generated method stub
		public static void main(String[] args)  {
			Employee employee=new
					CommissionEmployee(121, "amit", 2.1, 2000000);
			System.out.println(employee.getPayment());
		}
	}


