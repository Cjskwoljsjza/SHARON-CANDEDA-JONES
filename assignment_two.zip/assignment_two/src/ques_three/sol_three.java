package ques_three;

public class sol_three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SavingsAccount account=new SavingsAccount("ravi", "4343433434", 30000, 5, 1000);
	
		
		Account account2=new 
			CurrentAccount("rajiv", "543545445", 500000, "AB1234", 50000);
		
	}

}
