package ques_two;

public class sol_two {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookStore bookstore = new BookStore("harman", 5);
		bookstore.sell("spring in acton",2);
		bookstore.display();
	}

}
