package ques_five;

public class CommisionEmployee {

}
