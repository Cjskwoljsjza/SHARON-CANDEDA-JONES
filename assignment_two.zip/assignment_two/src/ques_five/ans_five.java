package ques_five;

public class ans_five {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
